﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Window4.xaml
    /// </summary>
    public partial class Window4 : Window
    {
        public Window4()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            WpfApp1.svorotenin_readyDataSet svorotenin_readyDataSet = ((WpfApp1.svorotenin_readyDataSet)(this.FindResource("svorotenin_readyDataSet")));
            // Загрузить данные в таблицу Разговор. Можно изменить этот код как требуется.
            WpfApp1.svorotenin_readyDataSetTableAdapters.РазговорTableAdapter svorotenin_readyDataSetРазговорTableAdapter = new WpfApp1.svorotenin_readyDataSetTableAdapters.РазговорTableAdapter();
            svorotenin_readyDataSetРазговорTableAdapter.Fill(svorotenin_readyDataSet.Разговор);
            System.Windows.Data.CollectionViewSource разговорViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("разговорViewSource")));
            разговорViewSource.View.MoveCurrentToFirst();
        }
    }
}
