﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Window3.xaml
    /// </summary>
    public partial class Window3 : Window
    {
        public Window3()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            WpfApp1.svorotenin_readyDataSet svorotenin_readyDataSet = ((WpfApp1.svorotenin_readyDataSet)(this.FindResource("svorotenin_readyDataSet")));
            // Загрузить данные в таблицу Тариф. Можно изменить этот код как требуется.
            WpfApp1.svorotenin_readyDataSetTableAdapters.ТарифTableAdapter svorotenin_readyDataSetТарифTableAdapter = new WpfApp1.svorotenin_readyDataSetTableAdapters.ТарифTableAdapter();
            svorotenin_readyDataSetТарифTableAdapter.Fill(svorotenin_readyDataSet.Тариф);
            System.Windows.Data.CollectionViewSource тарифViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("тарифViewSource")));
            тарифViewSource.View.MoveCurrentToFirst();
        }
    }
}
