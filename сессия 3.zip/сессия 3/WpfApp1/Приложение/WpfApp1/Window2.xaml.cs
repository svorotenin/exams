﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            WpfApp1.svorotenin_readyDataSet svorotenin_readyDataSet = ((WpfApp1.svorotenin_readyDataSet)(this.FindResource("svorotenin_readyDataSet")));
            // Загрузить данные в таблицу Телефон. Можно изменить этот код как требуется.
            WpfApp1.svorotenin_readyDataSetTableAdapters.ТелефонTableAdapter svorotenin_readyDataSetТелефонTableAdapter = new WpfApp1.svorotenin_readyDataSetTableAdapters.ТелефонTableAdapter();
            svorotenin_readyDataSetТелефонTableAdapter.Fill(svorotenin_readyDataSet.Телефон);
            System.Windows.Data.CollectionViewSource телефонViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("телефонViewSource")));
            телефонViewSource.View.MoveCurrentToFirst();
        }
    }
}
